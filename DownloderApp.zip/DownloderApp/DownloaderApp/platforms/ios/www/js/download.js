
//document.getElementById("myButton").addEventListener("click", myFunction);
//
//function myFunction(){
//    alert("Bazinga!!!  you called letMeCallYou")
//    
//}

document.getElementById("myButton").addEventListener("click", myFunction);
function myFunction(){
 //   alert("Initiating download")

    var fileTransfer = new FileTransfer();
    var uri = encodeURI("https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-zip-file.zip");
    fileURL = cordova.file.documentsDirectory+"zip_5MB.zip";
    fileTransfer.download(uri,
                          fileURL,
                          function(entry) {
        console.log("download complete: " + entry.toURL());
        runZip();
    },function(error) {
        console.log("download error source " + error.source);
        console.log("download error target " + error.target);
        console.log("download error code" + error.code);
    }, false,{
    headers: {
        "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
    }
    });
}

function runZip() {
    var ZipPath = cordova.file.documentsDirectory+"zip_5MB.zip"

    var ZipExtractDirectory = cordova.file.documentsDirectory;
    var printFile = cordova.file.documentsDirectory+"sample.txt"
    JJzip.unzip(ZipPath, {target:ZipExtractDirectory},function(data){
        
        var proceed = confirm("Downloaded the file Do you want to print?");
        if (proceed) {
            cordova.plugins.printer.print(printFile);
        } else {
            alert("File is available at path :" +  cordova.file.documentsDirectory)
        }
        
      
        /* Wow everything goes good, but just in case verify data.success */
    },function(error){
        alert("error runzipping")
        /* Wow something goes wrong, check the error.message */
    })
    

}
